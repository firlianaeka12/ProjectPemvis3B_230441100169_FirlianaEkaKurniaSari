/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author ASUS
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Dailist extends javax.swing.JFrame {

    private DefaultTableModel tableModel;
    private String username;
    private com.toedter.calendar.JDateChooser dateChooser;
    private Connection conn;
    
    
    class NonEditableTableModel extends DefaultTableModel {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    }
    
    public Dailist(String username) {
        this.username = username;
        initComponents();  
        
        conn = koneksi.getConnection(); 
        
        dateChooser = new com.toedter.calendar.JDateChooser();
        dateChooser.setDateFormatString("dd MMMM yyyy"); 
        jdtanggal.add(dateChooser); 

    btnsimpan.addActionListener(e -> {
        loadData(); 
    });
    btnupdate.addActionListener(e -> {
        loadData(); 
    });
    btnhapus.addActionListener(e -> {
        loadData(); 
    });
    
    tblkegiatan.addMouseListener(new java.awt.event.MouseAdapter() { 
    public void mouseClicked(java.awt.event.MouseEvent evt) {
        tblkegiatanMouseClicked(evt);
    }
});
    
    conn = koneksi.getConnection();

    tableModel = new NonEditableTableModel();
    tblkegiatan.setModel(tableModel);
    

    tableModel.addColumn("Prioritas");
    tableModel.addColumn("Tanggal");
    tableModel.addColumn("Waktu");
    tableModel.addColumn("Kegiatan");
    tableModel.addColumn("Status");

    loadData(); 
    setVisible(true);
    
    }
   
    private void tblkegiatanMouseClicked(java.awt.event.MouseEvent evt) {
        int selectedRow = tblkegiatan.getSelectedRow();
    if (selectedRow != -1) {
        
        tfprioritas.setText(tblkegiatan.getValueAt(selectedRow, 0).toString());
        
        
        String tanggalInput = tblkegiatan.getValueAt(selectedRow, 1).toString();
        
        try {
            
            SimpleDateFormat inputFormat = new SimpleDateFormat("dd MMMM yyyy", new Locale("id", "ID"));
            Date date = inputFormat.parse(tanggalInput);
            
            
            jdtanggal.setDate(date);  
            
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(this, "Error parsing tanggal: " + ex.getMessage());
        }

        
        tfwaktu.setText(tblkegiatan.getValueAt(selectedRow, 2).toString());
        tfkegiatan.setText(tblkegiatan.getValueAt(selectedRow, 3).toString());
        
        
        String status = tblkegiatan.getValueAt(selectedRow, 4).toString();
        cbstatus.setSelected("selesai".equalsIgnoreCase(status));
    }
    }
    
    private void loadData() {
       tableModel.setRowCount(0);  
       String query = "SELECT prioritas, tanggal, waktu, kegiatan, status FROM daylist WHERE username = ? ORDER BY prioritas ASC";  
    
    try (PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setString(1, username);
        ResultSet rs = stmt.executeQuery();
        
        
        SimpleDateFormat mysqlFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat displayFormat = new SimpleDateFormat("dd MMMM yyyy", new Locale("id", "ID"));
        
        while (rs.next()) {
            int prioritas = rs.getInt("prioritas");
            String tanggal = rs.getString("tanggal");
            String waktu = rs.getString("waktu");
            String kegiatan = rs.getString("kegiatan");
            String status = rs.getString("status");

            
            String tanggalFormatted = "";
            try {
                Date date = mysqlFormat.parse(tanggal);
                tanggalFormatted = displayFormat.format(date);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            
            tableModel.addRow(new Object[]{prioritas, tanggalFormatted, waktu, kegiatan, status});
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat memuat data dari database: " + ex.getMessage());
    }
    }
     
    private void clearInputFields() { 
        tfprioritas.setText("");
        jdtanggal.setDate(null); 
        tfwaktu.setText(""); 
        tfkegiatan.setText("");
        cbstatus.setSelected(false);
    }
    private void updatePrioritasAfterDelete() {
    String query = "UPDATE daylist SET prioritas = prioritas - 1 WHERE username = ? AND prioritas > ?";
    
    try (PreparedStatement stmt = conn.prepareStatement(query)) {
        
        int prioritasToDelete = Integer.parseInt(tfprioritas.getText()); 
        stmt.setString(1, username);
        stmt.setInt(2, prioritasToDelete);
        stmt.executeUpdate();
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat mengupdate prioritas: " + ex.getMessage());
    }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        tfprioritas = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        tfwaktu = new javax.swing.JTextField();
        tfkegiatan = new javax.swing.JTextField();
        cbstatus = new javax.swing.JCheckBox();
        btnsimpan = new javax.swing.JButton();
        btnhapus = new javax.swing.JButton();
        btnreset = new javax.swing.JButton();
        btnupdate = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jdtanggal = new com.toedter.calendar.JDateChooser();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblkegiatan = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(198, 224, 245));

        jPanel5.setBackground(new java.awt.Color(192, 207, 222));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel4.setText("Daily Todo List ");
        jPanel5.add(jLabel4);

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));
        jTabbedPane1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N

        jPanel2.setBackground(new java.awt.Color(194, 210, 225));

        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton2.setText("Keluar ");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setText("Prioritas :");

        tfprioritas.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel5.setText("Tanggal :");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel6.setText("Waktu :");

        tfwaktu.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N

        tfkegiatan.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        tfkegiatan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfkegiatanActionPerformed(evt);
            }
        });

        cbstatus.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cbstatus.setText("Status");

        btnsimpan.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnsimpan.setText("Simpan ");
        btnsimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsimpanActionPerformed(evt);
            }
        });

        btnhapus.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnhapus.setText("Hapus ");
        btnhapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhapusActionPerformed(evt);
            }
        });

        btnreset.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnreset.setText("Reset");
        btnreset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnresetActionPerformed(evt);
            }
        });

        btnupdate.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnupdate.setText("Update");
        btnupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdateActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel9.setText("Kegiatan :");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfprioritas, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(cbstatus, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(tfkegiatan, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(26, 26, 26)
                                .addComponent(btnupdate))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jdtanggal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(tfwaktu, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(26, 26, 26)
                                .addComponent(btnsimpan)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnreset)
                            .addComponent(btnhapus))))
                .addGap(489, 489, 489)
                .addComponent(jButton2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(tfprioritas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel5)
                        .addComponent(btnsimpan)
                        .addComponent(btnhapus))
                    .addComponent(jdtanggal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(tfwaktu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfkegiatan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(btnupdate)
                    .addComponent(btnreset))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cbstatus)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addGap(37, 37, 37))
        );

        jTabbedPane1.addTab("DaiList", jPanel2);

        tblkegiatan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Prioritas", "Tanggal", "Waktu", "Kegiatan", "Status"
            }
        ));
        jScrollPane1.setViewportView(tblkegiatan);

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Downloads\\Blue Watercolor Background Card Landscape.png")); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 480, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 477, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 3, Short.MAX_VALUE)))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(62, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 241, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        jTabbedPane1.addTab("Table", jPanel3);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 480, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdateActionPerformed
        try {
        if (tfprioritas.getText().isEmpty() || jdtanggal.getDate() == null || tfwaktu.getText().isEmpty() || tfkegiatan.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Semua kolom harus diisi!");
        return;
    }

    int prioritas = Integer.parseInt(tfprioritas.getText());
    Date date = jdtanggal.getDate();  
    String waktu = tfwaktu.getText();
    String kegiatan = tfkegiatan.getText();
    String status = cbstatus.isSelected() ? "selesai" : "belum";

    SimpleDateFormat mysqlFormat = new SimpleDateFormat("yyyy-MM-dd");
    String tanggalFormatted = mysqlFormat.format(date);

    SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
    Date time = timeFormat.parse(waktu);
    String waktuFormatted = timeFormat.format(time);

    String query = "UPDATE daylist SET prioritas = ?, tanggal = ?, waktu = ?, kegiatan = ?, status = ? WHERE username = ? AND prioritas = ?";
    try (PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setInt(1, prioritas);
        stmt.setString(2, tanggalFormatted);
        stmt.setString(3, waktuFormatted);
        stmt.setString(4, kegiatan);
        stmt.setString(5, status); 
        stmt.setString(6, username);
        stmt.setInt(7, prioritas);

        int rowsAffected = stmt.executeUpdate();
        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(this, "Tugas berhasil diupdate!");
        } else {
            JOptionPane.showMessageDialog(this, "Tidak ada tugas yang diperbarui. Pastikan data yang ingin diupdate ada.");
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Kesalahan basis data: " + ex.getMessage());
    }
}     catch (ParseException | NumberFormatException ex) {
    JOptionPane.showMessageDialog(this, "Terjadi kesalahan: " + ex.getMessage());
}
    loadData();
    clearInputFields();    
    }//GEN-LAST:event_btnupdateActionPerformed

    private void tfkegiatanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfkegiatanActionPerformed
        
    }//GEN-LAST:event_tfkegiatanActionPerformed

    private void btnsimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsimpanActionPerformed
        try {
    if (tfprioritas.getText().isEmpty() || jdtanggal.getDate() == null || tfwaktu.getText().isEmpty() || tfkegiatan.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Semua kolom harus diisi!");
        return;
    }

    int prioritas = Integer.parseInt(tfprioritas.getText());
    Date date = jdtanggal.getDate();  
    String waktu = tfwaktu.getText();
    String kegiatan = tfkegiatan.getText();
    String status = cbstatus.isSelected() ? "selesai" : "belum";

   
    SimpleDateFormat mysqlFormat = new SimpleDateFormat("yyyy-MM-dd");
    String tanggalFormatted = mysqlFormat.format(date);

    SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
    Date time = timeFormat.parse(waktu);
    String waktuFormatted = timeFormat.format(time);

    String query = "INSERT INTO daylist (username, prioritas, tanggal, waktu, kegiatan, status) VALUES (?, ?, ?, ?, ?, ?)";
    try (PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setString(1, username);
        stmt.setInt(2, prioritas);
        stmt.setString(3, tanggalFormatted);
        stmt.setString(4, waktuFormatted);
        stmt.setString(5, kegiatan);
        stmt.setString(6, status); 
        stmt.executeUpdate();
        JOptionPane.showMessageDialog(this, "Tugas berhasil disimpan!");
    }
} catch (ParseException | SQLException | NumberFormatException ex) {
    JOptionPane.showMessageDialog(this, "Terjadi kesalahan: " + ex.getMessage());
}
    loadData();
    clearInputFields();
    }//GEN-LAST:event_btnsimpanActionPerformed

    private void btnhapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhapusActionPerformed
        String kegiatan = tfkegiatan.getText();
        String query = "DELETE FROM daylist WHERE username = ? AND kegiatan = ?";
    
    try (PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setString(1, username);
        stmt.setString(2, kegiatan);
        stmt.executeUpdate();
        JOptionPane.showMessageDialog(this, "Tugas berhasil dihapus!");
        
        
        updatePrioritasAfterDelete();  
        
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat menghapus dari database: " + ex.getMessage());
    }
    
    
    loadData();
    clearInputFields();
    }//GEN-LAST:event_btnhapusActionPerformed

    private void btnresetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnresetActionPerformed
        tfprioritas.setText("");         
        jdtanggal.setDate(null);         
        tfwaktu.setText("");             
        tfkegiatan.setText("");          
        cbstatus.setSelected(false);    
    }//GEN-LAST:event_btnresetActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Dailist.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Dailist.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Dailist.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Dailist.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnhapus;
    private javax.swing.JButton btnreset;
    private javax.swing.JButton btnsimpan;
    private javax.swing.JButton btnupdate;
    private javax.swing.JCheckBox cbstatus;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private com.toedter.calendar.JDateChooser jdtanggal;
    private javax.swing.JTable tblkegiatan;
    private javax.swing.JTextField tfkegiatan;
    private javax.swing.JTextField tfprioritas;
    private javax.swing.JTextField tfwaktu;
    // End of variables declaration//GEN-END:variables
}
